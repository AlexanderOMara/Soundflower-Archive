sudo kextload Soundflower.kext
