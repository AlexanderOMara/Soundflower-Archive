sudo kextunload Soundflower.kext
sudo kextunload /System/Library/Extensions/Soundflower.kext
sudo chown -R root:wheel Soundflower.kext
sudo chmod -R 755 Soundflower.kext
