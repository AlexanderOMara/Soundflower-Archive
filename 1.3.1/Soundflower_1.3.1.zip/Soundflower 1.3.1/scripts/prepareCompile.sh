sudo chown -R nevyn Soundflower.kext
